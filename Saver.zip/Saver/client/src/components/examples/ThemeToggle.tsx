import ThemeToggle from '../ThemeToggle';

export default function ThemeToggleExample() {
  return (
    <div className="p-6">
      <ThemeToggle />
    </div>
  );
}
