import Converter from '../../pages/Converter';

export default function ConverterExample() {
  return <Converter />;
}
